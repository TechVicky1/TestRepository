﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Boundary;
using Pacman.Entity;

namespace Pacman.Control
{
    public class ControlPacman
    {
        public IPacmanClient gameClient;
        public IPacmanData gameData;
        public Player thePlayer;
        private CommandHandler playerTurnHandler;

        public ControlPacman()
        {
            this.gameData = GameFactory.GetInstance().TheData;
            this.gameClient = GameFactory.GetInstance().TheClient;
            playerTurnHandler = new CommandHandler();
        }

        public void PrintWelcome()
        {
            gameClient.PlayerMessage(gameData.GetWelcomeMessage());
        }

        public void SetupPlayer()
        {
            String playerName = gameClient.GetReply("What name do you choose to be known by?");
            thePlayer = new Player(playerName);
            thePlayer.CurrentLocation = gameData.GetStartingLocation();
            gameClient.PlayerMessage("Welcome " + playerName + "\n\n");
            gameClient.PlayerMessage("You find yourself looking at ");
            gameClient.PlayerMessage(gameData.GetStartingLocation().Description);
        }

        public void RunGame()
        {
            PrintWelcome();
            SetupPlayer();
            while (handlePlayerTurn())
            {
            }
            gameClient.GetReply("\n\n<<Hit enter to exit>>");
        }

        private bool handlePlayerTurn()
        {
            CommandResponse playerResponse = playerTurnHandler.ProcessTurn(gameClient.GetCommand(), thePlayer);
            gameClient.PlayerMessage(playerResponse.Message);
            return !playerResponse.FinishedGame;
        }

    }
}
