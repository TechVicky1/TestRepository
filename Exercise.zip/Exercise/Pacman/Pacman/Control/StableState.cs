﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Entity;

namespace Pacman.Control
{
     public class StableState : CommandState
    {
        public StableState()
            : base()
        {
            AvailableCommands.Add("go", new MoveCommand());
            AvailableCommands.Add("move", new MoveCommand());
            AvailableCommands.Add("report", new ReportCommand());
        }

        public override CommandState Update(Player thePlayer)
        {
            return new DynamicState();
        }
    }
}
