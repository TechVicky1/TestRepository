﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman.Entity
{
    public class Player
    {
        private String name;
        private Location currentLocation;

        public Player(String name) : this()
        {
            Name = name;
        }

        public Player()
        {
        }

        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        public void print()
        {
            Console.WriteLine("Name: " + this.name);
        }

        public Location CurrentLocation
        {
            get { return currentLocation; }
            set { currentLocation = value; }
        }

    }
}
