﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman.Entity
{
    public class Exit
    {
        private String description;
        private Pacman.Entity.Location destination;

        public Exit(String description, Location destination)
        {
            Description = description;
            Destination = destination;
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public Location Destination
        {
            get { return destination; }
            set { destination = value; }
        }
    }
}
