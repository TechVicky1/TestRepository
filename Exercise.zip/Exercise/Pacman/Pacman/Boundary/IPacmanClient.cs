﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman.Boundary
{
    public interface IPacmanClient
    {
        /// 
		/// <param name="question"></param>
		String GetReply(String question);

        /// 
        /// <param name="message"></param>
        void PlayerMessage(String message);
        String GetCommand();
    }
}
