﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Boundary;
using Pacman.Control;
using Pacman.Entity;

namespace DataImpl
{
    public class HardCodedData : IPacmanData
    {
        private Location AdminOffice, ITDepartment, Toilets, StaffRoom, Library, Lab, SupervisorOffice, LectureRoom, GamingArea, LunchRoom;

        public HardCodedData()
        {
            createLocations();
        }

        public Location GetStartingLocation()
        {
            return AdminOffice;
        }

        public String GetWelcomeMessage()
        {
            return "Welcome to Pacman World";
        }

        private void createLocations()
        {
            AdminOffice = new Location("A lift which lift you to the center of nowhere. Lets go hunt something", "LabsRoom");
            SupervisorOffice = new Location("A creepy place with a few bunch of Zombies", "SupervisorOffice");
            Toilets = new Location("The place which helps one feel lighter than ever before for sure", "Toilets");
            ITDepartment = new Location("A mysterious place with a lot of hidden treasures and one can just play around ", "ITDepartment");
            Lab = new Location("An access point to the shop(Hint: Can find free coins/weapons", "Lab");
            Library = new Location("The knowledge room", "Library");
            GamingArea = new Location("Another destructed area where zombies have taken over innocent people", "GamingArea");
            LectureRoom = new Location("The House of evil - The place where zombie boss resides", "LectureRoom");
            LunchRoom = new Location("A place where zombies are feeding upon innocent people", "LunchRoom");
            StaffRoom = new Location("A place to get reloaded by paying nothing", "StaffRoom");

            AdminOffice.AddExit("south", new Exit("Caution! You are about to see a bunch of devils - Zombies", SupervisorOffice));
            SupervisorOffice.AddExit("north", new Exit("You are entering the safest zone - University centre zone", AdminOffice));

            AdminOffice.AddExit("west", new Exit("You see a place with lots of high level computers", ITDepartment));
            ITDepartment.AddExit("east", new Exit("You are entering the safest zone - University centre zone", AdminOffice));

            Toilets.AddExit("south", new Exit("You are entering the safest zone - University centre zone", AdminOffice));
            AdminOffice.AddExit("north", new Exit("You see a stress releiving zone", Toilets));

            SupervisorOffice.AddExit("northwest", new Exit("You see a place with lots of high level computers", ITDepartment));
            ITDepartment.AddExit("southeast", new Exit("Caution! You are about to see a bunch of devils - Zombies", SupervisorOffice));

            ITDepartment.AddExit("west", new Exit("You see lots of computers as it is a Lab room", Lab));
            Lab.AddExit("east", new Exit("You see a place with lots of high level computers", ITDepartment));

            AdminOffice.AddExit("east", new Exit("You see a room with lots of book", Library));
            Library.AddExit("west", new Exit("You are entering the safest zone - University centre zone", AdminOffice));

            SupervisorOffice.AddExit("south", new Exit("You see a terrifying place with the dangerous villain", LectureRoom));
            LectureRoom.AddExit("north", new Exit("Caution! You are about to see a bunch of devils - Zombies", SupervisorOffice));

            Toilets.AddExit("north", new Exit("You see another terrified place with zombies.", GamingArea));
            GamingArea.AddExit("south", new Exit("You see a stress releiving zone", Toilets));

            Library.AddExit("east", new Exit("Room where you may fulfil your needs", LunchRoom));
            LunchRoom.AddExit("west", new Exit("you see a room with keys", Library));

            LunchRoom.AddExit("south", new Exit("You may find Zombies, not available most of the times", LunchRoom));
            StaffRoom.AddExit("north", new Exit("You see a room with lots of book", Library));
        }
    }
}
